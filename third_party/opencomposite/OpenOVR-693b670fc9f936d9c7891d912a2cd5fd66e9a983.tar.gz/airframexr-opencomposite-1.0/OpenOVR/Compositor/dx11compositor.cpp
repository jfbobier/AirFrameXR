#include "stdafx.h"

#if defined(SUPPORT_DX) && defined(SUPPORT_DX11)

#include "dx11compositor.h"

#include "../Misc/Config.h"
#include "../Misc/xr_ext.h"

#include <d3dcompiler.h> // For compiling shaders! D3DCompile

#pragma comment(lib, "d3dcompiler.lib")

// The draw that flips or converts (dxblit.h, shared with the D3D12 compositor)
#include "dxblit.h"

static void XTrace(LPCSTR lpszFormat, ...)
{
	va_list args;
	va_start(args, lpszFormat);
	int nBuf;
	char szBuffer[512]; // get rid of this hard-coded buffer
	nBuf = _vsnprintf_s(szBuffer, 511, lpszFormat, args);
	OutputDebugStringA(szBuffer);
	OOVR_LOG(szBuffer);
	va_end(args);
}

#define ERR(msg)                                                                                                                                       \
	{                                                                                                                                                  \
		std::string str = "Hit DX11-related error " + string(msg) + " at " __FILE__ ":" + std::to_string(__LINE__) + " func " + std::string(__func__); \
		OOVR_LOG(str.c_str());                                                                                                                         \
		OOVR_MESSAGE(str.c_str(), "Errored func!");                                                                                                    \
		/**((int*)NULL) = 0;*/                                                                                                                         \
		throw str;                                                                                                                                     \
	}

void DX11Compositor::ThrowIfFailed(HRESULT test)
{
	if ((test) != S_OK) {
		OOVR_FAILED_DX_ABORT(device->GetDeviceRemovedReason());
		throw "ThrowIfFailed err";
	}
}

ID3DBlob* d3d_compile_shader(const char* hlsl, const char* entrypoint, const char* target)
{
	DWORD flags = D3DCOMPILE_PACK_MATRIX_COLUMN_MAJOR | D3DCOMPILE_ENABLE_STRICTNESS | D3DCOMPILE_WARNINGS_ARE_ERRORS;
#ifdef _DEBUG
	flags |= D3DCOMPILE_SKIP_OPTIMIZATION | D3DCOMPILE_DEBUG;
#else
	flags |= D3DCOMPILE_OPTIMIZATION_LEVEL3;
#endif

	ID3DBlob *compiled, *errors;
	if (FAILED(D3DCompile(hlsl, strlen(hlsl), nullptr, nullptr, nullptr, entrypoint, target, flags, 0, &compiled, &errors)))
		OOVR_ABORTF("Error: D3DCompile failed %s", (char*)errors->GetBufferPointer());
	if (errors)
		errors->Release();

	return compiled;
}

ID3D11RenderTargetView* d3d_make_rtv(ID3D11Device* d3d_device, XrBaseInStructure& swapchain_img, const DXGI_FORMAT& format)
{
	ID3D11RenderTargetView* result = nullptr;

	// Get information about the swapchain image that OpenXR made for us
	XrSwapchainImageD3D11KHR& d3d_swapchain_img = (XrSwapchainImageD3D11KHR&)swapchain_img;

	// Create a render target view resource for the swapchain image
	D3D11_RENDER_TARGET_VIEW_DESC target_desc = {};
	target_desc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
	target_desc.Format = format;
	target_desc.Texture2D.MipSlice = 0;
	OOVR_FAILED_DX_ABORT(d3d_device->CreateRenderTargetView(d3d_swapchain_img.texture, &target_desc, &result));

	return result;
}

DX11Compositor::DX11Compositor(ID3D11Texture2D* initial)
{
	initial->GetDevice(&device);
	device->GetImmediateContext(&context);

	// Shaders for the draw that flips (inverted bounds) or converts (a format the runtime can't take as is)
	auto makeVs = [&](const char* entry, ID3D11VertexShader** out) {
		ID3DBlob* blob = d3d_compile_shader(oc_dx_blit_hlsl, entry, "vs_5_0");
		OOVR_FAILED_DX_ABORT(device->CreateVertexShader(blob->GetBufferPointer(), blob->GetBufferSize(), nullptr, out));
		blob->Release();
	};
	auto makePs = [&](const char* entry, ID3D11PixelShader** out) {
		ID3DBlob* blob = d3d_compile_shader(oc_dx_blit_hlsl, entry, "ps_5_0");
		OOVR_FAILED_DX_ABORT(device->CreatePixelShader(blob->GetBufferPointer(), blob->GetBufferSize(), nullptr, out));
		blob->Release();
	};
	makeVs("vs_fs", &fs_vshader);
	makeVs("vs_fs_noflip", &fs_vshader_noflip);
	makePs("ps_fs", &fs_pshader);
	makePs("ps_fs_lin", &fs_pshader_lin);

	// Create a texture sampler state description.
	D3D11_SAMPLER_DESC samplerDesc;
	samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.MipLODBias = 0.0f;
	samplerDesc.MaxAnisotropy = 4;
	samplerDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	samplerDesc.BorderColor[0] = 0;
	samplerDesc.BorderColor[1] = 0;
	samplerDesc.BorderColor[2] = 0;
	samplerDesc.BorderColor[3] = 0;
	samplerDesc.MinLOD = 0;
	samplerDesc.MaxLOD = 0;

	// Create the texture sampler state.
	OOVR_FAILED_DX_ABORT(device->CreateSamplerState(&samplerDesc, &quad_sampleState));
}

DX11Compositor::~DX11Compositor()
{
	for (auto&& rtv : swapchain_rtvs)
		rtv->Release();

	swapchain_rtvs.clear();

	for (auto&& tex : resolvedMSAATextures)
		tex->Release();

	resolvedMSAATextures.clear();

	for (IUnknown* obj : std::initializer_list<IUnknown*>{ fs_vshader, fs_vshader_noflip, fs_pshader, fs_pshader_lin, quad_sampleState })
		if (obj)
			obj->Release();

	context->Release();
	device->Release();
}

void DX11Compositor::CheckCreateSwapChain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, bool cube)
{
	XrSwapchainCreateInfo& desc = createInfo;

	auto* src = (ID3D11Texture2D*)texture->handle;

	D3D11_TEXTURE2D_DESC srcDesc;
	src->GetDesc(&srcDesc);
	const D3D11_TEXTURE2D_DESC fullDesc = srcDesc; // before the bounds shrink it: the MSAA resolve targets match the source

	if (bounds) {
		if (std::fabs(bounds->uMax - bounds->uMin) > 0.1)
			srcDesc.Width = uint32_t(float(srcDesc.Width) * std::fabs(bounds->uMax - bounds->uMin));
		if (std::fabs(bounds->vMax - bounds->vMin) > 0.1)
			srcDesc.Height = uint32_t(float(srcDesc.Height) * std::fabs(bounds->vMax - bounds->vMin));
	}

	if (cube) {
		// LibOVR can only use square cubemaps, while SteamVR can use any shape
		// Note we use CopySubresourceRegion later on, so this won't cause problems with that
		srcDesc.Height = srcDesc.Width = std::min(srcDesc.Height, srcDesc.Width);
	}

	bool usable = chain == NULL ? false : CheckChainCompatible(srcDesc, texture->eColorSpace);

	if (!usable) {
		OOVR_LOG("Generating new swap chain");

		if (bounds)
			OOVR_LOGF("Bounds: uMin %f uMax %f vMin %f vMax %f", bounds->uMin, bounds->uMax, bounds->vMin, bounds->vMax);
		OOVR_LOGF("Texture desc format: %d", srcDesc.Format);
		OOVR_LOGF("Texture desc bind flags: %d", srcDesc.BindFlags);
		OOVR_LOGF("Texture desc MiscFlags: %d", srcDesc.MiscFlags);
		OOVR_LOGF("Texture desc Usage: %d", srcDesc.Usage);
		OOVR_LOGF("Texture desc width: %d", srcDesc.Width);
		OOVR_LOGF("Texture desc height: %d", srcDesc.Height);

		// First, delete the old chain if necessary
		if (chain) {
			OOVR_FAILED_XR_ABORT(xrDestroySwapchain(chain));
			chain = XR_NULL_HANDLE;
		}

		for (auto&& rtv : swapchain_rtvs)
			rtv->Release();

		swapchain_rtvs.clear();

		for (auto&& tex : resolvedMSAATextures)
			tex->Release();

		resolvedMSAATextures.clear();

		// Figure out what format we need to use
		DxgiFormatInfo info = {};
		if (!GetFormatInfo(srcDesc.Format, info)) {
			OOVR_ABORTF("Unknown (by OC) DXGI texture format %d", srcDesc.Format);
		}
		bool useLinearFormat;
		switch (texture->eColorSpace) {
		case vr::ColorSpace_Gamma:
			useLinearFormat = false;
			break;
		case vr::ColorSpace_Linear:
			useLinearFormat = true;
			break;
		default:
			// As per the docs for the auto mode, at eight bits per channel or less it assumes gamma
			// (using such small channels for linear colour would result in significant banding)
			useLinearFormat = info.bpc > 8;
			break;
		}

		// The source's own variant when the runtime takes it (a copy, as before); else R16G16B16A16_FLOAT or R8G8B8A8 and a draw
		// converts (formats the runtime doesn't list, and display-encoded values without an sRGB variant, which aborted before)
		plan = PlanDxBlit(srcDesc.Format, info.srgb, info.linear, info.typeless, info.bpc, !useLinearFormat,
		    [](DXGI_FORMAT f) { return RuntimeOffersFormat(f); });
		DXGI_FORMAT type = plan.swapchain;
		OOVR_LOGF("Swapchain format %d for texture format %d (colour space %d): %s%s", type, srcDesc.Format, texture->eColorSpace,
		    plan.copy ? "copied" : "converted by a draw", plan.linearize ? ", sRGB decoded when drawn" : "");

		// Set aside the old format for checking later
		createInfoFormat = srcDesc.Format;

		// Make eye render buffer
		desc = { XR_TYPE_SWAPCHAIN_CREATE_INFO };
		// TODO desc.Type = cube ? ovrTexture_Cube : ovrTexture_2D;
		desc.faceCount = cube ? 6 : 1;
		desc.width = srcDesc.Width;
		desc.height = srcDesc.Height;
		desc.format = type;
		desc.mipCount = srcDesc.MipLevels;
		desc.sampleCount = 1;
		desc.arraySize = 1;
		desc.usageFlags = XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT | XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;

		XrResult result = xrCreateSwapchain(xr_session.get(), &desc, &chain);
		if (!XR_SUCCEEDED(result))
			OOVR_ABORTF("Cannot create DX texture swap chain: err %d", result);

		// Go through the images and retrieve them - this will be used later in Invoke, since OpenXR doesn't
		// have a convenient way to request one specific image.
		uint32_t imageCount;
		OOVR_FAILED_XR_ABORT(xrEnumerateSwapchainImages(chain, 0, &imageCount, nullptr));

		imagesHandles = std::vector<XrSwapchainImageD3D11KHR>(imageCount, { XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR });
		OOVR_FAILED_XR_ABORT(xrEnumerateSwapchainImages(chain,
		    imagesHandles.size(), &imageCount, (XrSwapchainImageBaseHeader*)imagesHandles.data()));

		OOVR_FALSE_ABORT(imageCount == imagesHandles.size());

		swapchain_rtvs.resize(imageCount, nullptr);

		for (uint32_t i = 0; i < imageCount; i++) {
			swapchain_rtvs[i] = d3d_make_rtv(device, (XrBaseInStructure&)imagesHandles[i], type);
		}

		if (srcDesc.SampleDesc.Count > 1) {
			OOVR_LOGF("Creating resolver textures for MSAA source with sample count x%d", srcDesc.SampleDesc.Count);
			// One slice, one mip, the source's full size (not the bounds'), readable by the draw
			D3D11_TEXTURE2D_DESC resDesc = fullDesc;
			resDesc.SampleDesc.Count = 1;
			resDesc.SampleDesc.Quality = 0;
			resDesc.MipLevels = 1;
			resDesc.ArraySize = 1;
			resDesc.Usage = D3D11_USAGE_DEFAULT;
			resDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
			resDesc.CPUAccessFlags = 0;
			resDesc.MiscFlags = 0;

			resolvedMSAATextures.resize(imageCount, nullptr);

			for (uint32_t i = 0; i < imageCount; i++) {
				device->CreateTexture2D(&resDesc, nullptr, &resolvedMSAATextures[i]);
			}
		}

		// TODO do we need to release the images at some point, or does the swapchain do that for us?
	}
}

void DX11Compositor::CopyToSwapchain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, std::optional<XruEye> eye, vr::EVRSubmitFlags submitFlags)
{
	auto* src = (ID3D11Texture2D*)texture->handle;

	// OpenXR swap chain doesn't support weird formats like DXGI_FORMAT_BC1_TYPELESS
	D3D11_TEXTURE2D_DESC srcDesc;
	src->GetDesc(&srcDesc);
	if (srcDesc.Format == DXGI_FORMAT_BC1_TYPELESS) {
		if (chain) {
			OOVR_FAILED_XR_ABORT(xrDestroySwapchain(chain));
			chain = XR_NULL_HANDLE;
		}
		return;
	}

	CheckCreateSwapChain(texture, bounds, false);

	// First reserve an image from the swapchain
	XrSwapchainImageAcquireInfo acquireInfo{ XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO };
	uint32_t currentIndex = 0;
	OOVR_FAILED_XR_ABORT(xrAcquireSwapchainImage(chain, &acquireInfo, &currentIndex));

	// Wait until the swapchain is ready - this makes sure the compositor isn't writing to it
	// We don't have to pass in currentIndex since it uses the oldest acquired-but-not-waited-on
	// image, so we should be careful with concurrency here.
	// XR_TIMEOUT_EXPIRED is considered successful but swapchain still can't be used so need to handle that
	XrSwapchainImageWaitInfo waitInfo{ XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO };
	waitInfo.timeout = 500000000; // time out in nano seconds - 500ms
	XrResult res;
	OOVR_FAILED_XR_ABORT(res = xrWaitSwapchainImage(chain, &waitInfo));

	if (res == XR_TIMEOUT_EXPIRED)
		OOVR_ABORTF("xrWaitSwapchainImage timeout");

	// Apparently SteamVR supports apps just sending array textures without specifying what's what.
	const UINT arrayIndex = (srcDesc.ArraySize > 1 && eye.has_value()) ? static_cast<UINT>(*eye) : 0;

	// An MSAA source is resolved first (into a one-slice texture), then copied or drawn like any other
	ID3D11Texture2D* readTex = src;
	UINT readSlice = arrayIndex;
	UINT readMips = srcDesc.MipLevels;
	if (srcDesc.SampleDesc.Count > 1) {
		context->ResolveSubresource(resolvedMSAATextures[currentIndex], 0, src, D3D11CalcSubresource(0, arrayIndex, srcDesc.MipLevels), plan.view);
		readTex = resolvedMSAATextures[currentIndex];
		readSlice = 0;
		readMips = 1;
	}

	// Invoke only passes bounds when inverting here (flipped bounds, or invertUsingShaders forcing it)
	bool flipped = bounds && bounds->vMin > bounds->vMax;
	if ((flipped || !plan.copy) && !swapchain_rtvs.empty()) {
		DrawToSwapchain(readTex, readSlice, bounds, flipped, currentIndex);
	} else {
		// Copy the source to the destination image
		D3D11_BOX sourceRegion;
		if (bounds) {
			sourceRegion.left = bounds->uMin == 0.0f ? 0 : createInfo.width;
			sourceRegion.right = bounds->uMin == 0.0f ? createInfo.width : createInfo.width * 2;
		} else {
			sourceRegion.left = 0;
			sourceRegion.right = createInfo.width;
		}
		sourceRegion.top = 0;
		sourceRegion.bottom = createInfo.height;
		sourceRegion.front = 0;
		sourceRegion.back = 1;

		context->CopySubresourceRegion(imagesHandles[currentIndex].texture, 0, 0, 0, 0, readTex, D3D11CalcSubresource(0, readSlice, readMips), &sourceRegion);
	}

	// Release the swapchain - OpenXR will use the last-released image in a swapchain
	XrSwapchainImageReleaseInfo releaseInfo{ XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO };
	OOVR_FAILED_XR_ABORT(xrReleaseSwapchainImage(chain, &releaseInfo));
}

void DX11Compositor::DrawToSwapchain(ID3D11Texture2D* tex, UINT slice, const vr::VRTextureBounds_t* bounds, bool flipped, uint32_t index)
{
	D3D11_TEXTURE2D_DESC texDesc;
	tex->GetDesc(&texDesc);

	// One slice, one mip, read with the plan's format (a typeless source needs an explicit one, or CreateShaderResourceView fails
	// with E_INVALIDARG). A one-slice array view also works on a plain 2D texture, so the shader has one declaration.
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.Format = plan.view;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2DARRAY;
	srvDesc.Texture2DArray.MostDetailedMip = 0;
	srvDesc.Texture2DArray.MipLevels = 1;
	srvDesc.Texture2DArray.FirstArraySlice = slice;
	srvDesc.Texture2DArray.ArraySize = 1;
	ID3D11ShaderResourceView* view = nullptr;
	OOVR_FAILED_DX_ABORT(device->CreateShaderResourceView(tex, &srvDesc, &view));

	// The game's immediate context: save what the draw changes and put it back, so the game finds its state as it left it
	ID3D11RenderTargetView* oldRtvs[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT] = {};
	ID3D11DepthStencilView* oldDsv = nullptr;
	context->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, oldRtvs, &oldDsv);
	ID3D11BlendState* oldBlend = nullptr;
	float oldBlendFactor[4];
	UINT oldSampleMask = 0;
	context->OMGetBlendState(&oldBlend, oldBlendFactor, &oldSampleMask);
	ID3D11DepthStencilState* oldDepth = nullptr;
	UINT oldStencilRef = 0;
	context->OMGetDepthStencilState(&oldDepth, &oldStencilRef);
	ID3D11RasterizerState* oldRaster = nullptr;
	context->RSGetState(&oldRaster);
	D3D11_VIEWPORT oldViewports[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
	UINT numViewports = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
	context->RSGetViewports(&numViewports, oldViewports);
	D3D11_RECT oldScissors[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
	UINT numScissors = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
	context->RSGetScissorRects(&numScissors, oldScissors);
	ID3D11InputLayout* oldLayout = nullptr;
	context->IAGetInputLayout(&oldLayout);
	D3D11_PRIMITIVE_TOPOLOGY oldTopology;
	context->IAGetPrimitiveTopology(&oldTopology);
	ID3D11VertexShader* oldVs = nullptr;
	context->VSGetShader(&oldVs, nullptr, nullptr);
	ID3D11HullShader* oldHs = nullptr;
	context->HSGetShader(&oldHs, nullptr, nullptr);
	ID3D11DomainShader* oldDs = nullptr;
	context->DSGetShader(&oldDs, nullptr, nullptr);
	ID3D11GeometryShader* oldGs = nullptr;
	context->GSGetShader(&oldGs, nullptr, nullptr);
	ID3D11PixelShader* oldPs = nullptr;
	context->PSGetShader(&oldPs, nullptr, nullptr);
	ID3D11ShaderResourceView* oldSrv = nullptr;
	context->PSGetShaderResources(0, 1, &oldSrv);
	ID3D11SamplerState* oldSampler = nullptr;
	context->PSGetSamplers(0, 1, &oldSampler);

	// The render target first: it unbinds the game's (the source may still be bound as one, which would null its view below)
	context->OMSetRenderTargets(1, &swapchain_rtvs[index], nullptr);
	context->OMSetBlendState(nullptr, nullptr, 0xffffffff);
	context->OMSetDepthStencilState(nullptr, 0);
	context->RSSetState(nullptr);

	// The quad covers the whole source texture (the viewport is sized to it); shift it so the bounds land on the swapchain.
	// vs_fs samples v = 1 - screen y (its top row samples vMin of flipped bounds), vs_fs_noflip v = screen y.
	float uMin = bounds ? bounds->uMin : 0.0f;
	float vMin = bounds ? bounds->vMin : 0.0f;
	D3D11_VIEWPORT viewport = {};
	viewport.Width = static_cast<float>(texDesc.Width);
	viewport.Height = static_cast<float>(texDesc.Height);
	viewport.MaxDepth = 1.0f;
	viewport.TopLeftX = -uMin * viewport.Width;
	viewport.TopLeftY = flipped ? -(1.0f - vMin) * viewport.Height : -vMin * viewport.Height;
	context->RSSetViewports(1, &viewport);
	D3D11_RECT rect = { 0, 0, static_cast<LONG>(createInfo.width), static_cast<LONG>(createInfo.height) };
	context->RSSetScissorRects(1, &rect);

	float clear_colour[4] = { 0.f, 0.f, 0.f, 0.f };
	context->ClearRenderTargetView(swapchain_rtvs[index], clear_colour);

	context->IASetInputLayout(nullptr);
	context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
	context->VSSetShader(flipped ? fs_vshader : fs_vshader_noflip, nullptr, 0);
	context->HSSetShader(nullptr, nullptr, 0);
	context->DSSetShader(nullptr, nullptr, 0);
	context->GSSetShader(nullptr, nullptr, 0);
	context->PSSetShader(plan.linearize ? fs_pshader_lin : fs_pshader, nullptr, 0);
	context->PSSetShaderResources(0, 1, &view);
	context->PSSetSamplers(0, 1, &quad_sampleState);
	context->Draw(4, 0);

	// Put the game's state back (its source view and render targets last, in that order)
	context->PSSetSamplers(0, 1, &oldSampler);
	context->PSSetShaderResources(0, 1, &oldSrv);
	context->PSSetShader(oldPs, nullptr, 0);
	context->GSSetShader(oldGs, nullptr, 0);
	context->DSSetShader(oldDs, nullptr, 0);
	context->HSSetShader(oldHs, nullptr, 0);
	context->VSSetShader(oldVs, nullptr, 0);
	context->IASetPrimitiveTopology(oldTopology);
	context->IASetInputLayout(oldLayout);
	if (numScissors)
		context->RSSetScissorRects(numScissors, oldScissors);
	if (numViewports)
		context->RSSetViewports(numViewports, oldViewports);
	context->RSSetState(oldRaster);
	context->OMSetDepthStencilState(oldDepth, oldStencilRef);
	context->OMSetBlendState(oldBlend, oldBlendFactor, oldSampleMask);
	context->OMSetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, oldRtvs, oldDsv);

	// The Get calls added a reference
	for (IUnknown* obj : std::initializer_list<IUnknown*>{ oldDsv, oldBlend, oldDepth, oldRaster, oldLayout, oldVs, oldHs, oldDs, oldGs, oldPs, oldSrv, oldSampler })
		if (obj)
			obj->Release();
	for (ID3D11RenderTargetView* rtv : oldRtvs)
		if (rtv)
			rtv->Release();
	view->Release();
}

void DX11Compositor::InvokeCubemap(const vr::Texture_t* textures)
{
	CheckCreateSwapChain(&textures[0], nullptr, true);

#ifdef OC_XR_PORT
	ID3D11Texture2D* tex = nullptr;
	ERR("TODO cubemap");
#else
	int currentIndex = 0;
	OOVR_FAILED_OVR_ABORT(ovr_GetTextureSwapChainCurrentIndex(OVSS, chain, &currentIndex));

	OOVR_FAILED_OVR_ABORT(ovr_GetTextureSwapChainBufferDX(OVSS, chain, currentIndex, IID_PPV_ARGS(&tex)));
#endif

	ID3D11Texture2D* faceSrc;

	// Front
	faceSrc = (ID3D11Texture2D*)textures[0].handle;
	context->CopySubresourceRegion(tex, 5, 0, 0, 0, faceSrc, 0, nullptr);

	// Back
	faceSrc = (ID3D11Texture2D*)textures[1].handle;
	context->CopySubresourceRegion(tex, 4, 0, 0, 0, faceSrc, 0, nullptr);

	// Left
	faceSrc = (ID3D11Texture2D*)textures[2].handle;
	context->CopySubresourceRegion(tex, 0, 0, 0, 0, faceSrc, 0, nullptr);

	// Right
	faceSrc = (ID3D11Texture2D*)textures[3].handle;
	context->CopySubresourceRegion(tex, 1, 0, 0, 0, faceSrc, 0, nullptr);

	// Top
	faceSrc = (ID3D11Texture2D*)textures[4].handle;
	context->CopySubresourceRegion(tex, 2, 0, 0, 0, faceSrc, 0, nullptr);

	// Bottom
	faceSrc = (ID3D11Texture2D*)textures[5].handle;
	context->CopySubresourceRegion(tex, 3, 0, 0, 0, faceSrc, 0, nullptr);

	tex->Release();
}

bool DX11Compositor::CheckChainCompatible(D3D11_TEXTURE2D_DESC& inputDesc, vr::EColorSpace colourSpace)
{
	bool usable = true;
#define FAIL(name)                             \
	do {                                       \
		usable = false;                        \
		OOVR_LOG("Resource mismatch: " #name); \
	} while (0);
#define CHECK(name, chainName)                  \
	if (inputDesc.name != createInfo.chainName) \
		FAIL(name);

	CHECK(Width, width)
	CHECK(Height, height)
	CHECK(MipLevels, mipCount)

	if (inputDesc.Format != createInfoFormat) {
		FAIL("Format");
	}

	// CHECK_ADV(SampleDesc.Count, SampleCount);
	// CHECK_ADV(SampleDesc.Quality);
#undef CHECK
#undef FAIL

	return usable;
}

bool DX11Compositor::GetFormatInfo(DXGI_FORMAT format, DX11Compositor::DxgiFormatInfo& out)
{
#define DEF_FMT_BASE(typeless, linear, srgb, bpp, bpc, channels)            \
	{                                                                       \
		out = DxgiFormatInfo{ srgb, linear, typeless, bpp, bpc, channels }; \
		return true;                                                        \
	}

#define DEF_FMT_NOSRGB(name, bpp, bpc, channels) \
	case name##_TYPELESS:                        \
	case name##_UNORM:                           \
		DEF_FMT_BASE(name##_TYPELESS, name##_UNORM, DXGI_FORMAT_UNKNOWN, bpp, bpc, channels)

#define DEF_FMT(name, bpp, bpc, channels) \
	case name##_TYPELESS:                 \
	case name##_UNORM:                    \
	case name##_UNORM_SRGB:               \
		DEF_FMT_BASE(name##_TYPELESS, name##_UNORM, name##_UNORM_SRGB, bpp, bpc, channels)

#define DEF_FMT_UNORM(linear, bpp, bpc, channels) \
	case linear:                                  \
		DEF_FMT_BASE(DXGI_FORMAT_UNKNOWN, linear, DXGI_FORMAT_UNKNOWN, bpp, bpc, channels)

	// Note that this *should* have pretty much all the types we'll ever see in games
	// Filtering out the non-typeless and non-unorm/srgb types, this is all we're left with
	// (note that types that are only typeless and don't have unorm/srgb variants are dropped too)
	switch (format) {
		// The relatively traditional 8bpp 32-bit types
		DEF_FMT(DXGI_FORMAT_R8G8B8A8, 32, 8, 4)
		DEF_FMT(DXGI_FORMAT_B8G8R8A8, 32, 8, 4)
		DEF_FMT(DXGI_FORMAT_B8G8R8X8, 32, 8, 3)

		// Some larger linear-only types
		DEF_FMT_NOSRGB(DXGI_FORMAT_R16G16B16A16, 64, 16, 4)
		DEF_FMT_NOSRGB(DXGI_FORMAT_R10G10B10A2, 32, 10, 4)

		// Float types, linear only. A runtime may list only R16G16B16A16_FLOAT of these (VDXR does): PlanDxBlit then
		// converts the others with a draw.
	case DXGI_FORMAT_R16G16B16A16_FLOAT:
		DEF_FMT_BASE(DXGI_FORMAT_R16G16B16A16_TYPELESS, DXGI_FORMAT_R16G16B16A16_FLOAT, DXGI_FORMAT_UNKNOWN, 64, 16, 4)
	case DXGI_FORMAT_R32G32B32A32_FLOAT:
		DEF_FMT_BASE(DXGI_FORMAT_R32G32B32A32_TYPELESS, DXGI_FORMAT_R32G32B32A32_FLOAT, DXGI_FORMAT_UNKNOWN, 128, 32, 4)
		DEF_FMT_UNORM(DXGI_FORMAT_R11G11B10_FLOAT, 32, 11, 3)

		// A jumble of other weird types
		DEF_FMT_UNORM(DXGI_FORMAT_B5G6R5_UNORM, 16, 5, 3)
		DEF_FMT_UNORM(DXGI_FORMAT_B5G5R5A1_UNORM, 16, 5, 4)
		DEF_FMT_UNORM(DXGI_FORMAT_R10G10B10_XR_BIAS_A2_UNORM, 32, 10, 4)
		DEF_FMT_UNORM(DXGI_FORMAT_B4G4R4A4_UNORM, 16, 4, 4)
		DEF_FMT(DXGI_FORMAT_BC1, 64, 16, 4)

	default:
		// Unknown type
		return false;
	}

#undef DEF_FMT
#undef DEF_FMT_NOSRGB
#undef DEF_FMT_BASE
#undef DEF_FMT_UNORM
}

#endif

#pragma once

#include "dxblit.h"
#include "dxcompositor.h"

class DX11Compositor : public Compositor {
public:
	DX11Compositor(ID3D11Texture2D* td);

	virtual ~DX11Compositor() override;

	// Override
	virtual void CopyToSwapchain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, std::optional<XruEye> eye, vr::EVRSubmitFlags submitFlags) override;
	virtual bool CanInvertInCopy() override { return true; }

	virtual void InvokeCubemap(const vr::Texture_t* textures) override;
	virtual bool SupportsCubemap() override { return true; }

	ID3D11Device* GetDevice() { return device; }

protected:
	void CheckCreateSwapChain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, bool cube);

	void ThrowIfFailed(HRESULT test);

	bool CheckChainCompatible(D3D11_TEXTURE2D_DESC& inputDesc, vr::EColorSpace colourSpace);

	// The full-screen draw into swapchain image `index` that flips (inverted bounds) or converts (plan.copy false) a slice of `tex`
	void DrawToSwapchain(ID3D11Texture2D* tex, UINT slice, const vr::VRTextureBounds_t* bounds, bool flipped, uint32_t index);

	ID3D11Device* device = nullptr;
	ID3D11DeviceContext* context = nullptr;

	ID3D11SamplerState* quad_sampleState = nullptr;
	ID3D11VertexShader* fs_vshader = nullptr;
	ID3D11VertexShader* fs_vshader_noflip = nullptr;
	ID3D11PixelShader* fs_pshader = nullptr;
	ID3D11PixelShader* fs_pshader_lin = nullptr;

	// The swapchain format and whether a copy or a draw fills it (set with the swapchain)
	DxBlitPlan plan;

	std::vector<XrSwapchainImageD3D11KHR> imagesHandles;
	std::vector<ID3D11RenderTargetView*> swapchain_rtvs;
	std::vector<ID3D11Texture2D*> resolvedMSAATextures;

	struct DxgiFormatInfo {
		/// The different versions of this format, set to DXGI_FORMAT_UNKNOWN if absent.
		/// Both the SRGB and linear formats should be UNORM.
		DXGI_FORMAT srgb, linear, typeless;

		/// THe bits per pixel, bits per channel, and the number of channels
		int bpp, bpc, channels;
	};

	/**
	 * Gets information about a given format into the output variable. Returns true if the texture was
	 * found, if not it returns false and leaves out in an undefined state.
	 */
	static bool GetFormatInfo(DXGI_FORMAT format, DxgiFormatInfo& out);
};

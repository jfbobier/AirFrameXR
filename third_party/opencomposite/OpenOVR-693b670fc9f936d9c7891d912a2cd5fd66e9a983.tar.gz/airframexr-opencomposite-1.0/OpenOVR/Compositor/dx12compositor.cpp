#include "stdafx.h"

#if defined(SUPPORT_DX) && defined(SUPPORT_DX12)

#include "dx12compositor.h"
#include "dxblit.h"

#include <string>

#include <atlbase.h>

#include <DirectXMath.h>
#include <d3dcompiler.h>

#include <d3d12.h>

#include "../Misc/Config.h"
#include "../Misc/xr_ext.h"

#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "d3d12.lib")

using namespace vr;
using namespace std;
using glm::min;

namespace {
ID3DBlob* CompileBlitShader(const char* entrypoint, const char* target)
{
	DWORD flags = D3DCOMPILE_PACK_MATRIX_COLUMN_MAJOR | D3DCOMPILE_ENABLE_STRICTNESS | D3DCOMPILE_WARNINGS_ARE_ERRORS | D3DCOMPILE_OPTIMIZATION_LEVEL3;
	ID3DBlob *compiled = nullptr, *errors = nullptr;
	if (FAILED(D3DCompile(oc_dx_blit_hlsl, strlen(oc_dx_blit_hlsl), nullptr, nullptr, nullptr, entrypoint, target, flags, 0, &compiled, &errors)))
		OOVR_ABORTF("D3D12 blit: D3DCompile of %s failed: %s", entrypoint, errors ? (char*)errors->GetBufferPointer() : "?");
	if (errors)
		errors->Release();
	return compiled;
}

D3D12_RESOURCE_BARRIER Transition(ID3D12Resource* resource, D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after)
{
	D3D12_RESOURCE_BARRIER b = {};
	b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
	b.Transition.pResource = resource;
	b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
	b.Transition.StateBefore = before;
	b.Transition.StateAfter = after;
	return b;
}

void WaitForFence(ID3D12Fence* fence, UINT64 completionValue, HANDLE waitEvent)
{
	if (fence->GetCompletedValue() < completionValue) {
		fence->SetEventOnCompletion(completionValue, waitEvent);
		WaitForSingleObject(waitEvent, INFINITE);
	}
}
} // namespace

DX12Compositor::DX12Compositor(D3D12TextureData_t* td)
{
	queue = td->m_pCommandQueue;
	queue->GetDevice(IID_PPV_ARGS(&device));
}

DX12Compositor::~DX12Compositor()
{
	for (auto event : frameFenceEvents) {
		CloseHandle(event);
	}

	device->Release();
}

void DX12Compositor::CheckCreateSwapChain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, bool cube)
{
	XrSwapchainCreateInfo& desc = createInfo;

	auto* src = (D3D12TextureData_t*)texture->handle;

	D3D12_RESOURCE_DESC srcDesc;
	srcDesc = src->m_pResource->GetDesc();

	if (bounds) {
		if (std::fabs(bounds->uMax - bounds->uMin) > 0.1)
			srcDesc.Width = uint32_t(float(srcDesc.Width) * std::fabs(bounds->uMax - bounds->uMin));
		if (std::fabs(bounds->vMax - bounds->vMin) > 0.1)
			srcDesc.Height = uint32_t(float(srcDesc.Height) * std::fabs(bounds->vMax - bounds->vMin));
	}

	if (cube) {
		// LibOVR can only use square cubemaps, while SteamVR can use any shape
		// Note we use CopySubresourceRegion later on, so this won't cause problems with that
		auto min = std::min(static_cast<UINT64>(srcDesc.Height), srcDesc.Width);
		srcDesc.Width = min;
		srcDesc.Height = static_cast<UINT>(min);
	}

	bool usable = chain == NULL ? false : CheckChainCompatible(srcDesc, texture->eColorSpace);

	if (!usable) {
		OOVR_LOG("Generating new swap chain");

		if (bounds)
			OOVR_LOGF("Bounds: uMin %f uMax %f vMin %f vMax %f", bounds->uMin, bounds->uMax, bounds->vMin, bounds->vMax);
		OOVR_LOGF("Texture desc format: %d", srcDesc.Format);
		OOVR_LOGF("Texture desc flags:  %d", srcDesc.Flags);
		OOVR_LOGF("Texture desc width:  %d", srcDesc.Width);
		OOVR_LOGF("Texture desc height: %d", srcDesc.Height);

		// The GPU may still run this compositor's last command lists, which use the old images, heaps and allocators
		for (size_t i = 0; i < frameFences.size(); i++)
			WaitForFence(frameFences[i].Get(), fenceValues[i], frameFenceEvents[i]);

		// First, delete the old chain if necessary
		if (chain) {
			OOVR_FAILED_XR_ABORT(xrDestroySwapchain(chain));
			chain = XR_NULL_HANDLE;
		}

		// Figure out what format we need to use
		DxgiFormatInfo info = {};
		if (!GetFormatInfo(srcDesc.Format, info)) {
			OOVR_ABORTF("Unknown (by OC) DXGI texture format %d", srcDesc.Format);
		}
		bool useLinearFormat;
		switch (texture->eColorSpace) {
		case vr::ColorSpace_Gamma:
			useLinearFormat = false;
			break;
		case vr::ColorSpace_Linear:
			useLinearFormat = true;
			break;
		default:
			// As per the docs for the auto mode, at eight bits per channel or less it assumes gamma
			// (using such small channels for linear colour would result in significant banding)
			useLinearFormat = info.bpc > 8;
			break;
		}

		// As the D3D11 compositor: the source's own variant when the runtime takes it (a copy), else a draw converts
		plan = PlanDxBlit(srcDesc.Format, info.srgb, info.linear, info.typeless, info.bpc, !useLinearFormat,
		    [](DXGI_FORMAT f) { return RuntimeOffersFormat(f); });
		DXGI_FORMAT type = plan.swapchain;
		OOVR_LOGF("Swapchain format %d for texture format %d (colour space %d): %s%s", type, srcDesc.Format, texture->eColorSpace,
		    plan.copy ? "copied" : "converted by a draw", plan.linearize ? ", sRGB decoded when drawn" : "");
		for (auto& pso : blitPso)
			pso.Reset();

		// Set aside the old format for checking later
		createInfoFormat = srcDesc.Format;

		// Make eye render buffer
		desc = { XR_TYPE_SWAPCHAIN_CREATE_INFO };
		// TODO desc.Type = cube ? ovrTexture_Cube : ovrTexture_2D;
		desc.faceCount = cube ? 6 : 1;
		desc.width = static_cast<uint32_t>(srcDesc.Width);
		desc.height = srcDesc.Height;
		desc.format = type;
		desc.mipCount = srcDesc.MipLevels;
		desc.sampleCount = 1;
		desc.arraySize = 1;
		desc.usageFlags = XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT | XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;

		XrResult result = xrCreateSwapchain(xr_session.get(), &desc, &chain);
		if (!XR_SUCCEEDED(result))
			OOVR_ABORTF("Cannot create DX texture swap chain: err %d", result);

		// Go through the images and retrieve them - this will be used later in Invoke, since OpenXR doesn't
		// have a convenient way to request one specific image.
		uint32_t imageCount;
		OOVR_FAILED_XR_ABORT(xrEnumerateSwapchainImages(chain, 0, &imageCount, nullptr));

		imagesHandles = std::vector<XrSwapchainImageD3D12KHR>(imageCount, { XR_TYPE_SWAPCHAIN_IMAGE_D3D12_KHR });
		OOVR_FAILED_XR_ABORT(xrEnumerateSwapchainImages(chain,
		    imagesHandles.size(), &imageCount, (XrSwapchainImageBaseHeader*)imagesHandles.data()));

		OOVR_FALSE_ABORT(imageCount == imagesHandles.size());

		for (auto event : frameFenceEvents) {
			CloseHandle(event);
		}

		commandLists.resize(imageCount);
		commandAllocators.resize(imageCount);
		frameFenceEvents.resize(imageCount);
		frameFences.resize(imageCount);
		fenceValues.resize(imageCount);

		for (uint32_t i = 0; i < imageCount; i++) {
			frameFenceEvents[i] = CreateEvent(nullptr, FALSE, FALSE, nullptr);
			fenceValues[i] = 0;
			device->CreateFence(0, D3D12_FENCE_FLAG_NONE,
			    IID_PPV_ARGS(&frameFences[i]));

			device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,
			    IID_PPV_ARGS(&commandAllocators[i]));
			device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT,
			    commandAllocators[i].Get(), nullptr,
			    IID_PPV_ARGS(&commandLists[i]));
			commandLists[i]->Close();
		}

		// For the draw: one render target view per image, one shader-visible slot per image for the source's view
		// (the slot is rewritten only after that image's fence, like its command list)
		D3D12_DESCRIPTOR_HEAP_DESC heapDesc = {};
		heapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
		heapDesc.NumDescriptors = imageCount;
		OOVR_FAILED_DX_ABORT(device->CreateDescriptorHeap(&heapDesc, IID_PPV_ARGS(&rtvHeap)));
		heapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
		heapDesc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
		OOVR_FAILED_DX_ABORT(device->CreateDescriptorHeap(&heapDesc, IID_PPV_ARGS(&srvHeap)));
		rtvStride = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
		srvStride = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

		D3D12_RENDER_TARGET_VIEW_DESC rtvDesc = {};
		rtvDesc.Format = type;
		rtvDesc.ViewDimension = D3D12_RTV_DIMENSION_TEXTURE2D;
		for (uint32_t i = 0; i < imageCount; i++) {
			D3D12_CPU_DESCRIPTOR_HANDLE handle = rtvHeap->GetCPUDescriptorHandleForHeapStart();
			handle.ptr += i * rtvStride;
			device->CreateRenderTargetView(imagesHandles[i].texture, &rtvDesc, handle);
		}
		// TODO do we need to release the images at some point, or does the swapchain do that for us?
	}
}

void DX12Compositor::CopyToSwapchain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, std::optional<XruEye> eye, vr::EVRSubmitFlags submitFlags)
{
	D3D12TextureData_t* input = (D3D12TextureData_t*)texture->handle;

	// OpenXR swap chain doesn't support weird formats like DXGI_FORMAT_BC1_TYPELESS
	D3D12_RESOURCE_DESC srcDesc;
	srcDesc = input->m_pResource->GetDesc();
	if (srcDesc.Format == DXGI_FORMAT_BC1_TYPELESS) {
		if (chain) {
			OOVR_FAILED_XR_ABORT(xrDestroySwapchain(chain));
			chain = XR_NULL_HANDLE;
		}
		return;
	}

	CheckCreateSwapChain(texture, bounds, false);

	// First reserve an image from the swapchain
	XrSwapchainImageAcquireInfo acquireInfo{ XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO };
	uint32_t currentIndex = 0;
	OOVR_FAILED_XR_ABORT(xrAcquireSwapchainImage(chain, &acquireInfo, &currentIndex));

	WaitForFence(frameFences[currentIndex].Get(),
	    fenceValues[currentIndex], frameFenceEvents[currentIndex]);

	commandAllocators[currentIndex]->Reset();
	auto commandList = commandLists[currentIndex].Get();
	commandList->Reset(commandAllocators[currentIndex].Get(), nullptr);

	// Wait until the swapchain is ready - this makes sure the compositor isn't writing to it
	// We don't have to pass in currentIndex since it uses the oldest acquired-but-not-waited-on
	// image, so we should be careful with concurrency here.
	// XR_TIMEOUT_EXPIRED is considered successful but swapchain still can't be used so need to handle that
	XrSwapchainImageWaitInfo waitInfo{ XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO };
	waitInfo.timeout = 500000000; // time out in nano seconds - 500ms
	XrResult res;
	OOVR_FAILED_XR_ABORT(res = xrWaitSwapchainImage(chain, &waitInfo));

	if (res == XR_TIMEOUT_EXPIRED)
		OOVR_ABORTF("xrWaitSwapchainImage timeout");

	// Copy the source to the destination image
	D3D12_BOX sourceRegion;
	if (bounds) {
		sourceRegion.left = bounds->uMin == 0.0f ? 0 : createInfo.width;
		sourceRegion.right = bounds->uMin == 0.0f ? createInfo.width : createInfo.width * 2;
	} else {
		sourceRegion.left = 0;
		sourceRegion.right = createInfo.width;
	}
	sourceRegion.top = 0;
	sourceRegion.bottom = createInfo.height;
	sourceRegion.front = 0;
	sourceRegion.back = 1;

	// TODO: MSAA sources (not supported before either)
	const UINT arraySize = srcDesc.DepthOrArraySize;
	const UINT slice = (arraySize > 1 && eye.has_value()) ? static_cast<UINT>(*eye) : 0;
	ID3D12Resource* dst = imagesHandles[currentIndex].texture;

	// Invoke only passes bounds when inverting here (flipped bounds, or invertUsingShaders forcing it)
	bool flipped = bounds && bounds->vMin > bounds->vMax;
	if (flipped || !plan.copy) {
		DrawToSwapchain(commandList, input->m_pResource, srcDesc, slice, bounds, flipped, currentIndex);
	} else {
		// OpenVR hands D3D12 textures over in PIXEL_SHADER_RESOURCE (Valve's hellovr_dx12), OpenXR hands its images out in
		// RENDER_TARGET; a copy needs COPY_SOURCE and COPY_DEST (the CopyResource here had no barrier), then both go back.
		D3D12_RESOURCE_BARRIER toCopy[2] = {
			Transition(input->m_pResource, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE),
			Transition(dst, D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_DEST),
		};
		commandList->ResourceBarrier(2, toCopy);

		// The region the swapchain was sized to (bounds only reach here with invertUsingShaders; the whole slice otherwise),
		// not CopyResource, which needs identical sizes and so failed on a swapchain sized to the bounds.
		D3D12_TEXTURE_COPY_LOCATION dstLoc = {};
		dstLoc.pResource = dst;
		dstLoc.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
		dstLoc.SubresourceIndex = 0;
		D3D12_TEXTURE_COPY_LOCATION srcLoc = {};
		srcLoc.pResource = input->m_pResource;
		srcLoc.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
		srcLoc.SubresourceIndex = slice * srcDesc.MipLevels; // mip 0 of the slice
		commandList->CopyTextureRegion(&dstLoc, 0, 0, 0, &srcLoc, &sourceRegion);

		D3D12_RESOURCE_BARRIER back[2] = {
			Transition(input->m_pResource, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE),
			Transition(dst, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_RENDER_TARGET),
		};
		commandList->ResourceBarrier(2, back);
	}

	commandList->Close();
	ID3D12CommandList* set[] = { commandList };
	queue->ExecuteCommandLists(1, set);

	// Release the swapchain - OpenXR will use the last-released image in a swapchain
	XrSwapchainImageReleaseInfo releaseInfo{ XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO };
	OOVR_FAILED_XR_ABORT(xrReleaseSwapchainImage(chain, &releaseInfo));

	const auto fenceValue = currentFenceValue;
	queue->Signal(frameFences[currentIndex].Get(), fenceValue);
	fenceValues[currentIndex] = fenceValue;
	++currentFenceValue;
}

ID3D12PipelineState* DX12Compositor::GetBlitPipeline(bool flipped, bool linearize)
{
	if (!blitRootSignature) {
		// One table with the source's view, one static sampler (as the D3D11 compositor's: linear, clamped, mip 0)
		D3D12_DESCRIPTOR_RANGE range = {};
		range.RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
		range.NumDescriptors = 1;
		range.OffsetInDescriptorsFromTableStart = D3D12_DESCRIPTOR_RANGE_OFFSET_APPEND;
		D3D12_ROOT_PARAMETER param = {};
		param.ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
		param.DescriptorTable.NumDescriptorRanges = 1;
		param.DescriptorTable.pDescriptorRanges = &range;
		param.ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
		D3D12_STATIC_SAMPLER_DESC sampler = {};
		sampler.Filter = D3D12_FILTER_MIN_MAG_MIP_LINEAR;
		sampler.AddressU = sampler.AddressV = sampler.AddressW = D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
		sampler.MaxAnisotropy = 1;
		sampler.ComparisonFunc = D3D12_COMPARISON_FUNC_NEVER;
		sampler.BorderColor = D3D12_STATIC_BORDER_COLOR_TRANSPARENT_BLACK;
		sampler.ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
		D3D12_ROOT_SIGNATURE_DESC rootDesc = {};
		rootDesc.NumParameters = 1;
		rootDesc.pParameters = &param;
		rootDesc.NumStaticSamplers = 1;
		rootDesc.pStaticSamplers = &sampler;
		ComPtr<ID3DBlob> blob, errors;
		if (FAILED(D3D12SerializeRootSignature(&rootDesc, D3D_ROOT_SIGNATURE_VERSION_1, &blob, &errors)))
			OOVR_ABORTF("D3D12 blit: root signature: %s", errors ? (char*)errors->GetBufferPointer() : "?");
		OOVR_FAILED_DX_ABORT(device->CreateRootSignature(0, blob->GetBufferPointer(), blob->GetBufferSize(), IID_PPV_ARGS(&blitRootSignature)));

		blitVs[0].Attach(CompileBlitShader("vs_fs_noflip", "vs_5_0"));
		blitVs[1].Attach(CompileBlitShader("vs_fs", "vs_5_0"));
		blitPs[0].Attach(CompileBlitShader("ps_fs", "ps_5_0"));
		blitPs[1].Attach(CompileBlitShader("ps_fs_lin", "ps_5_0"));
	}

	// One pipeline per vertex x pixel shader, for the current swapchain's format (reset with the swapchain)
	ComPtr<ID3D12PipelineState>& pso = blitPso[(flipped ? 2 : 0) + (linearize ? 1 : 0)];
	if (!pso) {
		D3D12_GRAPHICS_PIPELINE_STATE_DESC desc = {};
		desc.pRootSignature = blitRootSignature.Get();
		desc.VS = { blitVs[flipped]->GetBufferPointer(), blitVs[flipped]->GetBufferSize() };
		desc.PS = { blitPs[linearize]->GetBufferPointer(), blitPs[linearize]->GetBufferSize() };
		for (auto& rt : desc.BlendState.RenderTarget) {
			rt.SrcBlend = rt.SrcBlendAlpha = D3D12_BLEND_ONE;
			rt.DestBlend = rt.DestBlendAlpha = D3D12_BLEND_ZERO;
			rt.BlendOp = rt.BlendOpAlpha = D3D12_BLEND_OP_ADD;
			rt.LogicOp = D3D12_LOGIC_OP_NOOP;
			rt.RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
		}
		desc.SampleMask = UINT_MAX;
		desc.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID;
		desc.RasterizerState.CullMode = D3D12_CULL_MODE_NONE;
		desc.RasterizerState.DepthClipEnable = TRUE;
		desc.DepthStencilState.DepthEnable = FALSE;
		desc.DepthStencilState.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ZERO;
		desc.DepthStencilState.DepthFunc = D3D12_COMPARISON_FUNC_ALWAYS;
		desc.DepthStencilState.FrontFace = desc.DepthStencilState.BackFace = { D3D12_STENCIL_OP_KEEP, D3D12_STENCIL_OP_KEEP, D3D12_STENCIL_OP_KEEP, D3D12_COMPARISON_FUNC_ALWAYS };
		desc.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
		desc.NumRenderTargets = 1;
		desc.RTVFormats[0] = plan.swapchain;
		desc.SampleDesc.Count = 1;
		OOVR_FAILED_DX_ABORT(device->CreateGraphicsPipelineState(&desc, IID_PPV_ARGS(&pso)));
	}
	return pso.Get();
}

void DX12Compositor::DrawToSwapchain(ID3D12GraphicsCommandList* commandList, ID3D12Resource* src, const D3D12_RESOURCE_DESC& srcDesc, UINT slice,
    const vr::VRTextureBounds_t* bounds, bool flipped, uint32_t index)
{
	ID3D12PipelineState* pso = GetBlitPipeline(flipped, plan.linearize);

	// The source as a one-slice array (also valid on a plain 2D texture), read with the plan's format (a typeless
	// source needs an explicit one). It stays in PIXEL_SHADER_RESOURCE; the image is drawn in RENDER_TARGET, as handed out.
	D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.Format = plan.view;
	srvDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2DARRAY;
	srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
	srvDesc.Texture2DArray.MostDetailedMip = 0;
	srvDesc.Texture2DArray.MipLevels = 1;
	srvDesc.Texture2DArray.FirstArraySlice = slice;
	srvDesc.Texture2DArray.ArraySize = 1;
	D3D12_CPU_DESCRIPTOR_HANDLE srvCpu = srvHeap->GetCPUDescriptorHandleForHeapStart();
	srvCpu.ptr += index * srvStride;
	device->CreateShaderResourceView(src, &srvDesc, srvCpu);
	D3D12_GPU_DESCRIPTOR_HANDLE srvGpu = srvHeap->GetGPUDescriptorHandleForHeapStart();
	srvGpu.ptr += index * srvStride;
	D3D12_CPU_DESCRIPTOR_HANDLE rtv = rtvHeap->GetCPUDescriptorHandleForHeapStart();
	rtv.ptr += index * rtvStride;

	commandList->SetGraphicsRootSignature(blitRootSignature.Get());
	ID3D12DescriptorHeap* heaps[] = { srvHeap.Get() };
	commandList->SetDescriptorHeaps(1, heaps);
	commandList->SetGraphicsRootDescriptorTable(0, srvGpu);
	commandList->SetPipelineState(pso);
	commandList->OMSetRenderTargets(1, &rtv, FALSE, nullptr);

	// As the D3D11 compositor: the quad covers the whole source (the viewport is sized to it), shifted so the bounds land on the image
	float uMin = bounds ? bounds->uMin : 0.0f;
	float vMin = bounds ? bounds->vMin : 0.0f;
	D3D12_VIEWPORT viewport = {};
	viewport.Width = static_cast<float>(srcDesc.Width);
	viewport.Height = static_cast<float>(srcDesc.Height);
	viewport.MaxDepth = 1.0f;
	viewport.TopLeftX = -uMin * viewport.Width;
	viewport.TopLeftY = flipped ? -(1.0f - vMin) * viewport.Height : -vMin * viewport.Height;
	commandList->RSSetViewports(1, &viewport);
	D3D12_RECT scissor = { 0, 0, static_cast<LONG>(createInfo.width), static_cast<LONG>(createInfo.height) };
	commandList->RSSetScissorRects(1, &scissor);
	commandList->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
	commandList->DrawInstanced(4, 1, 0, 0);
}

void DX12Compositor::InvokeCubemap(const vr::Texture_t* textures)
{
	CheckCreateSwapChain(&textures[0], nullptr, true);

	OOVR_SOFT_ABORT("TODO cubemap");
}

bool DX12Compositor::CheckChainCompatible(D3D12_RESOURCE_DESC& inputDesc, vr::EColorSpace colourSpace)
{
	bool usable = true;
#define FAIL(name)                             \
	do {                                       \
		usable = false;                        \
		OOVR_LOG("Resource mismatch: " #name); \
	} while (0);
#define CHECK(name, chainName)                  \
	if (inputDesc.name != createInfo.chainName) \
		FAIL(name);

	CHECK(Width, width)
	CHECK(Height, height)
	CHECK(MipLevels, mipCount)

	if (inputDesc.Format != createInfoFormat) {
		FAIL("Format");
	}

	// CHECK_ADV(SampleDesc.Count, SampleCount);
	// CHECK_ADV(SampleDesc.Quality);
#undef CHECK
#undef FAIL

	return usable;
}

bool DX12Compositor::GetFormatInfo(DXGI_FORMAT format, DX12Compositor::DxgiFormatInfo& out)
{
#define DEF_FMT_BASE(typeless, linear, srgb, bpp, bpc, channels)            \
	{                                                                       \
		out = DxgiFormatInfo{ srgb, linear, typeless, bpp, bpc, channels }; \
		return true;                                                        \
	}

#define DEF_FMT_NOSRGB(name, bpp, bpc, channels) \
	case name##_TYPELESS:                        \
	case name##_UNORM:                           \
		DEF_FMT_BASE(name##_TYPELESS, name##_UNORM, DXGI_FORMAT_UNKNOWN, bpp, bpc, channels)

#define DEF_FMT(name, bpp, bpc, channels) \
	case name##_TYPELESS:                 \
	case name##_UNORM:                    \
	case name##_UNORM_SRGB:               \
		DEF_FMT_BASE(name##_TYPELESS, name##_UNORM, name##_UNORM_SRGB, bpp, bpc, channels)

#define DEF_FMT_UNORM(linear, bpp, bpc, channels) \
	case linear:                                  \
		DEF_FMT_BASE(DXGI_FORMAT_UNKNOWN, linear, DXGI_FORMAT_UNKNOWN, bpp, bpc, channels)

	// Note that this *should* have pretty much all the types we'll ever see in games
	// Filtering out the non-typeless and non-unorm/srgb types, this is all we're left with
	// (note that types that are only typeless and don't have unorm/srgb variants are dropped too)
	switch (format) {
		// The relatively traditional 8bpp 32-bit types
		DEF_FMT(DXGI_FORMAT_R8G8B8A8, 32, 8, 4)
		DEF_FMT(DXGI_FORMAT_B8G8R8A8, 32, 8, 4)
		DEF_FMT(DXGI_FORMAT_B8G8R8X8, 32, 8, 3)

		// Some larger linear-only types
		DEF_FMT_NOSRGB(DXGI_FORMAT_R16G16B16A16, 64, 16, 4)
		DEF_FMT_NOSRGB(DXGI_FORMAT_R10G10B10A2, 32, 10, 4)

		// Float types, linear only. A runtime may list only R16G16B16A16_FLOAT of these (VDXR does): PlanDxBlit then
		// converts the others with a draw.
	case DXGI_FORMAT_R16G16B16A16_FLOAT:
		DEF_FMT_BASE(DXGI_FORMAT_R16G16B16A16_TYPELESS, DXGI_FORMAT_R16G16B16A16_FLOAT, DXGI_FORMAT_UNKNOWN, 64, 16, 4)
	case DXGI_FORMAT_R32G32B32A32_FLOAT:
		DEF_FMT_BASE(DXGI_FORMAT_R32G32B32A32_TYPELESS, DXGI_FORMAT_R32G32B32A32_FLOAT, DXGI_FORMAT_UNKNOWN, 128, 32, 4)
		DEF_FMT_UNORM(DXGI_FORMAT_R11G11B10_FLOAT, 32, 11, 3)

		// A jumble of other weird types
		DEF_FMT_UNORM(DXGI_FORMAT_B5G6R5_UNORM, 16, 5, 3)
		DEF_FMT_UNORM(DXGI_FORMAT_B5G5R5A1_UNORM, 16, 5, 4)
		DEF_FMT_UNORM(DXGI_FORMAT_R10G10B10_XR_BIAS_A2_UNORM, 32, 10, 4)
		DEF_FMT_UNORM(DXGI_FORMAT_B4G4R4A4_UNORM, 16, 4, 4)
		DEF_FMT(DXGI_FORMAT_BC1, 64, 16, 4)

	default:
		// Unknown type
		return false;
	}

#undef DEF_FMT
#undef DEF_FMT_NOSRGB
#undef DEF_FMT_BASE
#undef DEF_FMT_UNORM
}

#endif

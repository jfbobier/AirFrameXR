#pragma once

#include "dxblit.h"
#include "dxcompositor.h"

class DX12Compositor : public Compositor {
public:
	DX12Compositor(vr::D3D12TextureData_t* td);

	// Override
	virtual ~DX12Compositor() override;

	// Override
	void CopyToSwapchain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, std::optional<XruEye> eye, vr::EVRSubmitFlags submitFlags) override;

	void InvokeCubemap(const vr::Texture_t* textures) override;
	virtual bool SupportsCubemap() override { return false; }
	virtual bool CanInvertInCopy() override { return true; }

	ComPtr<ID3D12Device> GetDevice() { return device; }

private:
	void CheckCreateSwapChain(const vr::Texture_t* texture, const vr::VRTextureBounds_t* bounds, bool cube);

	void ThrowIfFailed(HRESULT test);

	bool CheckChainCompatible(D3D12_RESOURCE_DESC& inputDesc, vr::EColorSpace colourSpace);

	// The full-screen draw into swapchain image `index` that flips (inverted bounds) or converts (plan.copy false) a slice of `src`
	void DrawToSwapchain(ID3D12GraphicsCommandList* commandList, ID3D12Resource* src, const D3D12_RESOURCE_DESC& srcDesc, UINT slice,
	    const vr::VRTextureBounds_t* bounds, bool flipped, uint32_t index);
	ID3D12PipelineState* GetBlitPipeline(bool flipped, bool linearize);

	ComPtr<ID3D12Device> device;
	ComPtr<ID3D12CommandQueue> queue;

	std::vector<ComPtr<ID3D12CommandAllocator>> commandAllocators;
	std::vector<ComPtr<ID3D12GraphicsCommandList>> commandLists;

	std::vector<HANDLE> frameFenceEvents;
	std::vector<ComPtr<ID3D12Fence>> frameFences;
	std::vector<UINT64> fenceValues;
	UINT64 currentFenceValue = 1; // was uninitialised; the fences start at 0

	// The swapchain format and whether a copy or a draw fills it (set with the swapchain)
	DxBlitPlan plan;

	// The draw's pipeline: built on the first draw; the pipelines and heaps follow the swapchain
	ComPtr<ID3D12RootSignature> blitRootSignature;
	ComPtr<ID3DBlob> blitVs[2]; // no flip, flip
	ComPtr<ID3DBlob> blitPs[2]; // passthrough, sRGB decode
	ComPtr<ID3D12PipelineState> blitPso[4]; // [flip * 2 + decode]
	ComPtr<ID3D12DescriptorHeap> rtvHeap, srvHeap;
	UINT rtvStride = 0, srvStride = 0;

	std::vector<XrSwapchainImageD3D12KHR> imagesHandles;

	struct DxgiFormatInfo {
		/// The different versions of this format, set to DXGI_FORMAT_UNKNOWN if absent.
		/// Both the SRGB and linear formats should be UNORM.
		DXGI_FORMAT srgb, linear, typeless;

		/// The bits per pixel, bits per channel, and the number of channels
		int bpp, bpc, channels;
	};

	/**
	 * Gets information about a given format into the output variable. Returns true if the texture was
	 * found, if not it returns false and leaves out in an undefined state.
	 */
	static bool GetFormatInfo(DXGI_FORMAT format, DxgiFormatInfo& out);
};

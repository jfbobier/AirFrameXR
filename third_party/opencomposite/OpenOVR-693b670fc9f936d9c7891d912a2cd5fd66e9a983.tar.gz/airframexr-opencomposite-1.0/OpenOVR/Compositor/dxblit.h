#pragma once

// Shared by the D3D11 and D3D12 compositors: the full-screen draw that replaces the copy when a copy can't do the job
// (vertically flipped bounds, or a texture format the runtime has no swapchain format for), and the choice between them.

#ifdef SUPPORT_DX

#include <dxgiformat.h>

// One quad over the whole source texture (the viewport is sized to it and shifted so the wanted bounds land on the
// swapchain). vs_fs flips vertically (texture row 0 at the bottom), vs_fs_noflip doesn't. ps_fs passes the colour
// through, ps_fs_lin decodes sRGB-encoded values to linear (the swapchain then holds linear values, as OpenXR expects).
constexpr char oc_dx_blit_hlsl[] = R"_(
Texture2DArray shaderTexture : register(t0); // viewed as a one-slice array, so a slice of an array texture reads the same way

SamplerState SampleType : register(s0);

struct psIn {
	float4 pos : SV_POSITION;
	float2 tex : TEXCOORD0;
};

psIn vs_fs(uint vI : SV_VERTEXID)
{
	psIn output;
    output.tex = float2(vI&1,vI>>1);
    output.pos = float4((output.tex.x-0.5f)*2,-(output.tex.y-0.5f)*2,0,1);
	output.tex.y = 1.0f - output.tex.y;
	return output;
}

psIn vs_fs_noflip(uint vI : SV_VERTEXID)
{
	psIn output;
	output.tex = float2(vI&1,vI>>1);
	output.pos = float4((output.tex.x-0.5f)*2,-(output.tex.y-0.5f)*2,0,1);
	return output;
}

float4 ps_fs(psIn inputPS) : SV_TARGET
{
	float4 textureColor = shaderTexture.Sample(SampleType, float3(inputPS.tex, 0));
	return textureColor;
}

float4 ps_fs_lin(psIn inputPS) : SV_TARGET
{
	float4 c = shaderTexture.Sample(SampleType, float3(inputPS.tex, 0));
	float3 lo = c.rgb / 12.92f;
	float3 hi = pow(abs((c.rgb + 0.055f) / 1.055f), 2.4f);
	c.rgb = lerp(hi, lo, step(c.rgb, 0.04045f));
	return c;
})_";

// How a submitted texture reaches its swapchain.
struct DxBlitPlan {
	DXGI_FORMAT swapchain = DXGI_FORMAT_UNKNOWN; // the swapchain's format
	DXGI_FORMAT view = DXGI_FORMAT_UNKNOWN; // the format a draw reads the source with (a concrete one for typeless sources)
	bool copy = true; // a plain copy gives the right colours; else a draw converts
	bool linearize = false; // a draw decodes sRGB-encoded values (it sees display-encoded values the view doesn't decode)
};

// src: the submitted texture's format; srgb / linear / typeless: its variants (DXGI_FORMAT_UNKNOWN if absent); bpc: bits per channel;
// gammaSource: the values are display-encoded (ColorSpace_Gamma, or Auto at 8 bits or less); offered(f): the runtime lists f.
//
// The swapchain takes the source's own variant (sRGB for display-encoded values, so the copied bits are decoded by the runtime) as
// before. New: when the runtime doesn't offer that variant (e.g. R11G11B10_FLOAT, R10G10B10A2_UNORM or R32G32B32A32_FLOAT on a
// runtime that only lists 8-bit and R16G16B16A16_FLOAT formats), or the source has display-encoded values and no sRGB variant
// (float or 10/16-bit with ColorSpace_Gamma, which aborted before), the swapchain takes R16G16B16A16_FLOAT (more than 8 bits) or
// R8G8B8A8 and a draw converts.
template <typename Offered>
DxBlitPlan PlanDxBlit(DXGI_FORMAT src, DXGI_FORMAT srgb, DXGI_FORMAT linear, DXGI_FORMAT typeless, int bpc, bool gammaSource, Offered offered)
{
	DxBlitPlan p;

	DXGI_FORMAT natural = (gammaSource && srgb != DXGI_FORMAT_UNKNOWN) ? srgb : linear;
	if (natural == DXGI_FORMAT_UNKNOWN)
		natural = src;

	p.swapchain = natural;
	if (!offered(p.swapchain)) {
		DXGI_FORMAT fallback = bpc > 8 ? DXGI_FORMAT_R16G16B16A16_FLOAT : (gammaSource ? DXGI_FORMAT_R8G8B8A8_UNORM_SRGB : DXGI_FORMAT_R8G8B8A8_UNORM);
		if (offered(fallback))
			p.swapchain = fallback;
	}

	// A typeless source has no format of its own to read with: take the variant the values are in (the sRGB view decodes them).
	p.view = (typeless != DXGI_FORMAT_UNKNOWN && src == typeless) ? natural : src;
	bool viewDecodes = srgb != DXGI_FORMAT_UNKNOWN && p.view == srgb;
	p.linearize = gammaSource && !viewDecodes;

	// A copy moves bits: only between variants of one format (same numeric type), and display-encoded values need an sRGB swapchain.
	bool variant = p.swapchain == src || (srgb != DXGI_FORMAT_UNKNOWN && p.swapchain == srgb) || (linear != DXGI_FORMAT_UNKNOWN && p.swapchain == linear);
	bool swapchainDecodes = srgb != DXGI_FORMAT_UNKNOWN && p.swapchain == srgb;
	p.copy = variant && (!gammaSource || swapchainDecodes);

	return p;
}

#endif
